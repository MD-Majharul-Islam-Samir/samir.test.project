// toggle icon navbar

// scroll sections
window.onscroll = () => {

    // sticky header

    // remove toggle icon and navbar when click navbar links (scroll)

    // animation footer on scroll
}